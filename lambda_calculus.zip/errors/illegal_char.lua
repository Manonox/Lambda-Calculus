local Error = require("errors.base")


---@class IllegalCharError : Error
local IllegalCharError = class("IllegalCharError", Error)

return IllegalCharError

