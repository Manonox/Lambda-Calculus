# Lambda-Calculus

Extra syntax rules apply

Bonus Task from my Theory of computation class
